import "./Home.css";
import React from "react";
export default function Home() {
  return (
    <div>
      <h2 className="heading1">Welcome to GenAI Playground!</h2>
      <div className="content"></div>
      </div>
  );
}
