import React from 'react'
import NavigationBar from '../NavigationBar/NavigationBar'


export default function Header () {
  return (
    <>
    <NavigationBar/>
    </>
  )
}
